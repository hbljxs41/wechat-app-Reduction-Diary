//index.js
//获取应用实例

const app = getApp()
// const DB = wx.cloud.database().collection("data_date")


Page({
  data: {
    motto: '',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
  },
  
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },

  onLoad: function () {
    // var that = this
    // wx.showModal({
    //   title: '温馨提示',
    //   content: '正在请求您的个人信息',
    //   success(res) {
    //     if (res.confirm) {
    //       wx.getUserProfile({
    //       desc: "获取你的昵称、头像、地区及性别",
    //       success: res => {
    //         console.log(res)
    //         app.globalData.userInfo = res.userInfo
    //       },
    //       fail: res => {
    //          //拒绝授权
    //         that.showErrorModal('您拒绝了请求');
    //         return;
    //       }
    //     })} else if (res.cancel) {
    //       //拒绝授权 showErrorModal是自定义的提示
    //       that.showErrorModal('您拒绝了请求');
    //       return;
    //     }
    //   }
    // }
    // )


  //   if (app.globalData.userInfo) 
  //   {
  //     this.setData({
  //       userInfo: app.globalData.userInfo,
  //       hasUserInfo: true
  //     })
  //   } 
  //   else if (this.data.canIUse)
  //   {
  //     // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
  //     // 所以此处加入 callback 以防止这种情况
  //     app.userInfoReadyCallback = res => {
  //       this.setData({
  //         userInfo: res.userInfo,
  //         hasUserInfo: true
  //       })
  //     }
  //   } 
  //   else 
  //   {
  //     // 在没有 open-type=getUserInfo 版本的兼容处理
  //     wx.getUserInfo({
  //       success: res => {
  //         app.globalData.userInfo = res.userInfo
  //         this.setData({
  //           userInfo: res.userInfo,
  //           hasUserInfo: true
  //         })
  //       }
  //     })
  //   }
  // },

  }
}
)
