var config = {
  key: '3e49ceec74d406c857e4255ac18a090b'
}

module.exports.Config = config;